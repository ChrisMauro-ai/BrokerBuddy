export function parseT12(csvText) {
  const lines = csvText.split('\n');
  const noiLine = lines.find(line => line.toLowerCase().includes('net operating income'));
  const noi = noiLine ? parseFloat(noiLine.replace(/[^0-9.]/g, '')) : 200000;
  return noi;
}

export function parseRentRoll(csvText) {
  const lines = csvText.split('\n');
  return lines.length - 1;
}
