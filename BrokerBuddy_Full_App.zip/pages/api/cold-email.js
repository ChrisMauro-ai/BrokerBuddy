import { OpenAI } from 'openai';

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

export default async function handler(req, res) {
  const { property } = req.body;
  try {
    const completion = await openai.chat.completions.create({
      messages: [
        { role: 'system', content: 'You are a CRE broker writing cold outreach emails to property owners.' },
        { role: 'user', content: `Write a short but effective cold outreach email for a broker trying to buy or list this type of property:\n${property}` }
      ],
      model: 'gpt-4o'
    });
    res.status(200).json({ email: completion.choices[0].message.content });
  } catch {
    res.status(500).json({ error: 'Failed to generate cold email' });
  }
}
