import { OpenAI } from 'openai';

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

export default async function handler(req, res) {
  const { valuation } = req.body;
  try {
    const completion = await openai.chat.completions.create({
      messages: [
        { role: 'system', content: 'You are a commercial real estate broker writing BOVs.' },
        { role: 'user', content: `Write a BOV draft email based on this:\n${valuation}` }
      ],
      model: 'gpt-4o'
    });
    res.status(200).json({ bov: completion.choices[0].message.content });
  } catch {
    res.status(500).json({ error: 'Failed to generate BOV' });
  }
}
